import csv,math,json,cmath
from pathlib import Path
from collections import defaultdict
from analytic_fourier_M0_engine import Model
ROOT=Path(__file__).parent
OLD=Path('/mnt/data/UCFT_BH050_5_6_Airy_exact_integral_20261012')
m=Model(2500,save_terms=True)

def csvwrite(name,headers,rows):
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(rows)

# EVERY Fourier harmonic's coefficient and exact integral primitive, including cumulative running subtotal.
rows=[]; prevname='';cv=0j
for item in m.ledger:
 name,nx,ny,cr,ci,ixr,ixi,iyr,iyi,tr,ti=item
 if name!=prevname:cv=0j;prevname=name
 cv+=complex(float(tr),float(ti))
 rows.append(item+[f'{cv.real:.16g}',f'{cv.imag:.16g}'])
csvwrite('BH050_W5_01_every_Fourier_integral_term.csv',['integral_name','nx','ny','coefficient_real','coefficient_imag','Ix_real','Ix_imag','Iy_real','Iy_imag','contribution_real','contribution_imag','running_real','running_imag'],rows)
# expanded harmonic source coefficients, stress field of g,l,cross uncentered and centered
modes=[]
for case,term in [('global',m.g),('local_plus',m.s[5]),('mixed_plus',m.x[5]),('local_minus',m.s[6]),('mixed_minus',m.x[6])]:
 airy, stress=term
 for tag,field in [('Phi_unit',airy),('sigma_x_centered_unit',stress[0]),('sigma_y_centered_unit',stress[1]),('tau_xy_centered_unit',stress[2])]:
  for k,c in sorted(field.d.items()):modes.append([case,tag,k[0],k[1],f'{c.real:.17g}',f'{c.imag:.17g}'])
csvwrite('BH050_W5_02_every_Airy_and_stress_harmonic.csv',['source','field','nx','ny','fourier_coefficient_real','fourier_coefficient_imag'],modes)
# old exact W5 coefficients, compare by 8 arbitrary numerical states, each coefficient exhaustiveness.
coefs={}
with (OLD/'BH050_W5_全部Galerkin解析单项式系数.csv').open(encoding='utf-8-sig') as f:
 for r in csv.DictReader(f):
  k={'R_W':'RW','R_A_plus':'RP','R_A_minus':'RM','P_N':'P'}.get(r['方程'])
  if k is None:continue
  d=(int(r['A_plus_power']),int(r['A_minus_power']),int(r['eps_y_power']))
  coefs[(k,d)]=float(r['系数_物理单位'])

def poly(name,a,b,e,der=None):
 out=0.;term_records=[]
 for (tag,(i,j,k)),c in coefs.items():
  if tag!=name:continue
  if der=='a':exp=i;expr=c*i*a**(i-1)*b**j*e**k if i else 0.
  elif der=='b':exp=j;expr=c*j*a**i*b**(j-1)*e**k if j else 0.
  elif der=='e':exp=k;expr=c*k*a**i*b**j*e**(k-1) if k else 0.
  else:exp=1;expr=c*a**i*b**j*e**k
  out+=expr
  term_records.append((tag,i,j,k,c,exp,expr,out))
 return out,term_records
for a,b,e in [(0,0,0),(.316462248204096,.503447015296702,-.000582834754985961),(.3,.6,-.001),(1.,2.,-.005),(-.03,.02,-.001),(2.,-1.,.001),(0,.5,-.01)]:
 z=m.compute(5,a,b,e,details=True)
 for tag in ['RW','RP','RM','P']:
  pv,_=poly(tag,a,b,e)
  if abs(pv-z[tag])>max(3e-5,1e-8*abs(z[tag])):raise RuntimeError((tag,a,b,e,pv,z[tag]))
# full paper reproducibility: previous 9 iteration values, every a^i,b^j,e^k, product, cumulative.
steps=[];detailed=[];partials=[]
with (OLD/'BH050_W5_牛顿手算迭代逐步账本.csv').open(encoding='utf-8-sig') as f:
 src=list(csv.DictReader(f))
for i,r in enumerate(src):
 a=float(r['Ap']);b=float(r['Am']);e=float(r['eps_y']);val=m.compute(5,a,b,e,details=True)
 f0,_=poly('RW',a,b,0.);f1=poly('RW',a,b,1.)[0]-f0
 ee=-f0/f1
 if abs(e-ee)>5e-12:raise RuntimeError(('e mismatch',i,e,ee))
 f0a=poly('RW',a,b,0.,'a')[0];f1a=poly('RW',a,b,1.,'a')[0]-f0a
 f0b=poly('RW',a,b,0.,'b')[0];f1b=poly('RW',a,b,1.,'b')[0]-f0b
 dea=-(f0a+ee*f1a)/f1;deb=-(f0b+ee*f1b)/f1
 Rp=poly('RP',a,b,e)[0];Rm=poly('RM',a,b,e)[0]
 ra=poly('RP',a,b,e,'a')[0];rb=poly('RP',a,b,e,'b')[0];re=poly('RP',a,b,e,'e')[0]
 sa=poly('RM',a,b,e,'a')[0];sb=poly('RM',a,b,e,'b')[0];se=poly('RM',a,b,e,'e')[0]
 J11=ra+re*dea;J12=rb+re*deb;J21=sa+se*dea;J22=sb+se*deb
 det=J11*J22-J12*J21
 da=(-Rp*J22+J12*Rm)/det;db=(J21*Rp-J11*Rm)/det
 rec=dict(iteration=i,Ap_mm=a,Am_mm=b,eps_y0=e,eps_x0=val['ex'],F0_N=f0,F1_N=f1,eps_y_from_quotient=ee,dF0_dAplus=f0a,dF1_dAplus=f1a,dF0_dAminus=f0b,dF1_dAminus=f1b,de_dAplus=dea,de_dAminus=deb,RW_N=val['RW'],RP_N=Rp,RM_N=Rm,RP_partial_Aplus=ra,RP_partial_Aminus=rb,RP_partial_e=re,RM_partial_Aplus=sa,RM_partial_Aminus=sb,RM_partial_e=se,J11=J11,J12=J12,J21=J21,J22=J22,J11J22=J11*J22,J12J21=J12*J21,detJ=det,Newton_num_plus=-Rp*J22+J12*Rm,Newton_num_minus=J21*Rp-J11*Rm,dAplus=da,dAminus=db,next_Ap=a+da,next_Am=b+db,P_MN=val['P'],P_core_MN=-2500*42*val['avg'][0][1]/1e6,P_top_MN=-2500*4*val['avg'][1][1]/1e6,P_bottom_MN=-2500*4*val['avg'][2][1]/1e6)
 steps.append(rec)
 for tag in ['RW','RP','RM','P']:
  _,trs=poly(tag,a,b,e)
  for (eq,j,k,l,c,exp,t,cum) in trs:
   detailed.append([i,eq,j,k,l,f'{a:.17g}',f'{b:.17g}',f'{e:.17g}',f'{c:.17g}',f'{a**j:.17g}',f'{b**k:.17g}',f'{e**l:.17g}',f'{t:.17g}',f'{cum:.17g}'])
 for tag in ['RW','RP','RM']:
  for derivative in ['a','b','e']:
   _,trs=poly(tag,a,b,e,derivative)
   for eq,j,k,l,c,fac,t,cum in trs:
    partials.append([i,eq,derivative,j,k,l,f'{c:.17g}',fac,f'{t:.17g}',f'{cum:.17g}'])
# write
csvwrite('BH050_W5_03_all_polynomial_coefficients.csv',['equation','degree_plus','degree_minus','degree_eps','coefficient','unit'],[[tag,*powers,f'{c:.17g}','N' if tag!='P' else 'MN'] for (tag,powers),c in coefs.items()])
for name,field,data in [('BH050_W5_04_all_Newton_steps.csv',list(steps[0].keys()),[[v[k] for k in steps[0]] for v in steps]),('BH050_W5_05_every_Newton_monomial_product.csv',['iter','eq','i','j','k','Ap','Am','e','coefficient','Ap_to_i','Am_to_j','e_to_k','term','cumulative'],detailed),('BH050_W5_06_every_Jacobian_polynomial_term.csv',['iter','eq','partial','i','j','k','coefficient','factor','term','cumulative'],partials)]:csvwrite(name,field,data)
W5=steps[-1];out=m.compute(5,W5['Ap_mm'],W5['Am_mm'],W5['eps_y0'],details=True)
(ROOT/'BH050_W5_07_final_state_all_layer_values.json').write_text(json.dumps({'parameter_ledger':{'B':2500,'L':5000,'a_h':2500,'tc':42,'ts':4,'zf':23,'Es':206000,'Ec':43400,'nu_s':.3,'nu_c':.2,'w0':6.25,'A0':.3515625,'N_plus':5,'N_minus':6,'m':4,'W':5,'alpha':m.alpha,'beta':m.beta,'kx5':10*m.alpha,'kx6':12*m.alpha,'ky':8*m.beta,'Ks':m.Ks,'Kc':m.Kc,'Ds':m.Ds,'Dc':m.Dc,'I00':m.i00,'I05':m.i0[5],'I06':m.i0[6],'I55':m.ii[5],'I66':m.ii[6]},'W5_final_Newton_step':W5,'full_three_layer_details':out},ensure_ascii=False,indent=2),encoding='utf8')
report=f'''# BH050 W=5 mm 人工复算母账本：有限谐波原函数与每一个系数、乘积、加减和迭代

**理论身份**：M0 三层拉压同性线弹性；上5、下6等效子板；m=4；无真实PBL节点逐点相容，无 UHPC 损伤/钢塑性。**W不是加载端缩，P不是W做功的共轭力，而由共同膜合力恢复。**

## 1. 输入符号

B=2500 mm，L=5000 mm，a_h=B=2500 mm，UHPC厚度 t_c=42 mm，钢面厚度 t_s=4 mm，钢面中面偏置 z_f=(42+4)/2=23 mm。E_c=43400 MPa，ν_c=0.20；E_s=206000 MPa，ν_s=0.30；w0=B/400=2500/400=6.25 mm；A0=(0.225B)/1600=(0.225×2500)/1600=562.5/1600=0.3515625 mm。N_plus=5，N_minus=6，m=4，W=5 mm。

alpha=π/B=π/2500={m.alpha:.17g} mm^(-1)；beta=π/a_h={m.beta:.17g} mm^(-1)；kx+=10π/2500={10*m.alpha:.17g}，kx-=12π/2500={12*m.alpha:.17g}，ky=8π/2500={8*m.beta:.17g}。

K_c=43400/(1−0.2²)=43400/(1−0.04)=43400/0.96={m.Kc:.17g} MPa；K_s=206000/(1−0.3²)=206000/(1−0.09)=206000/0.91={m.Ks:.17g} MPa。

D_c=E_c t_c³/[12(1−ν_c²)]={m.Dc:.17g} Nmm，D_s=E_s t_s³/[12(1−ν_s²)]={m.Ds:.17g} Nmm。

## 2. 变形场及导数

φ=sin(alpha x) sin(beta y)；ψ+=(1−cos(10 alpha x))(1−cos(8 beta y))；ψ-=(1−cos(12 alpha x))(1−cos(8 beta y))。

φ_x=alpha cos(alpha x)sin(beta y)；φ_y=beta sin(alpha x)cos(beta y)；φ_xx=−alpha²φ；φ_yy=−beta²φ；φ_xy=alpha beta cos(alpha x)cos(beta y)。

ψ_x=kx sin(kx x)(1−cos(ky y))；ψ_y=ky (1−cos(kx x))sin(ky y)；ψ_xx=kx² cos(kx x)(1−cos(ky y))；ψ_yy=ky²(1−cos(kx x))cos(ky y)；ψ_xy=kx ky sin(kx x)sin(ky y)。

w_c^tot=(w0+W)φ；w+^tot=(w0+W)φ+(A0+A+)ψ+；w-^tot=(w0+W)φ−(A0+A-)ψ-；应变按当前总构形减初始构形。

## 3. Airy兼容及严格原函数积分

∇⁴Φ_i=E_i{{Q_g(φ_xy²−φ_xx φ_yy)+Q_l(ψ_xy²−ψ_xx ψ_yy)±Q_cross(2φ_xy ψ_xy−φ_xx ψ_yy−φ_yy ψ_xx)}}。其中 Q_g=W(W+2w0)，Q_l=A(A+2A0)，Q_cross=W A0+(w0+W)A，UHPC只含Q_g。

每项全部转成 exp(i nx πx/B)exp(i ny πy/a_h)。频率(n_x,n_y)均是整数，乘积用索引相加作**有限卷积**；空间积分用解析原函数：J(0)=1，J(n)=2i/(nπ) 对奇数n，J(n)=0 对非零偶数n。

∫∫[c·exp(i nx πx/B)exp(i ny πy/a_h)]dxdy=Ba·c·J(nx)·J(ny)。每个因子 c，J(nx)，J(ny)，乘积，累加值已逐行输出（3616行），**不含任何高斯点或空间数值求积**。

源 Airy 的每一个复系数和应力二阶导数详见 CSV 02；每项非均匀应力减去其板面平均，然后再加上同一层由平均相容恢复的均匀应力，防止混合项均值重复计入。

## 4. 共同平均应变、三个膜弯虚功和荷载

设公共未知 e_x=ε_x0、e_y=ε_y0；χ_xi与χ_yi由完整初始缺陷 von Kármán应变的面积平均严格计算。σ̄_xi=K_i[(e_x+χ_xi)+ν_i(e_y+χ_yi)]，σ̄_yi=K_i[ν_i(e_x+χ_xi)+(e_y+χ_yi)]。

横向合力零：42 σ̄_xc+4 σ̄_x+ +4 σ̄_x- = 0，因此 e_x=−[ (42Kcνc+8Ksνs)e_y+42Kc(χ_xc+νcχ_yc)+4Ks(χ_x++νsχ_y+)+4Ks(χ_x-+νsχ_y-) ]/[42Kc+8Ks]。

整体 R_W=(Dc+2Ds)W I00+Ds(A+ I05−A- I06)+三层显式σ·∂ε/∂W积分=0；上侧 R_+=Ds(W I05+A+ I55)+上侧σ·∂ε/∂A+积分=0；下侧 R_-=Ds(−W I06+A- I66)+下侧σ·∂ε/∂A-积分=0。

所有积分的基础三角卷积参数和乘积存于 CSV 01，每个源谐波存于 CSV 02；最终全部 13+10+10 项残量系数和轴力六项系数存于 CSV 03。

总体压力 P_N=−2500[42σ̄_yc+4σ̄_y+ +4σ̄_y-]/10⁶ MN。不把W的共轭外力伪装成P。

## 5. 完整代数消元与每一轮牛顿计算

定义 A+=a、A-=b、e=ε_y0。三个残量为已归档多项式。R_W=F0(a,b)+F1(a,b)e；e=−F0/F1。

de/da=−[∂aF0+e∂aF1]/F1；de/db=−[∂bF0+e∂bF1]/F1。

J11=∂aR_++∂eR_+·de/da；J12=∂bR_++∂eR_+·de/db；J21=∂aR_-+∂eR_-·de/da；J22=∂bR_-+∂eR_-·de/db。

D=J11J22−J12J21；delta_a=(−R_+J22+J12R_-)/D；delta_b=(J21R_+−J11R_-)/D；a_next=a+delta_a，b_next=b+delta_b。

CSV 04：**9轮的全部** F0 F1 e x e_y/e_x 5个基本导数4个偏导4个J、2个行列式乘积、行列式、2个Newton分子、两更正、下一状态、P及3个分项P。

CSV 05：每轮**每一单项式** c·a^i·b^j·e^k 的c、各幂、乘积、逐行累计结果；CSV 06：每轮**每一个雅可比导数单项式**的i、j、k、系数、导数乘子、结果和累计。

## 6. W5最终自洽数据

W=5.0；A+={W5['Ap_mm']:.17g} mm；A-={W5['Am_mm']:.17g} mm；eps_y={W5['eps_y0']:.17g}；eps_x={W5['eps_x0']:.17g}。

P_total={W5['P_MN']:.15g} MN；P_c={W5['P_core_MN']:.15g} MN；P_+={W5['P_top_MN']:.15g} MN；P_-={W5['P_bottom_MN']:.15g} MN。三个平衡残量 R_W={out['RW']:.17g} N、R_+={out['RP']:.17g} N、R_-={out['RM']:.17g} N。

## 7. 复算操作顺序及可知局限

输入→三角模态→兼容源→Airy特解→源场应力→解析积分→均匀应力规范化→横向合力消元→三残量→轴向参考应变消元→二元Newton→P分项及残量。

如人工逐项复算，先按 CSV 02 计算源场，再按 CSV 01 验算所有原函数项；照 CSV 03–06 不跳步逐行算到第8轮，最后按 CSV 07 从材料本构复算所有层应力、分担比例和残量。

误差与局限：这是有限模态平均协调 M0，不满足实体PBL肋线及自由边逐点边界；钢壳单侧向外约束未纳入方程；线弹性不具有真实材料峰后软化；轴向波数m=4只是示范输入；FEM实际挠度并非都达到B/25，不许外推FEM曲线。
'''
(ROOT/'BH050_W5_00_complete_human_reproduction_readme.md').write_text(report,encoding='utf-8')
print('Fourier rows',len(rows),'Airy rows',len(modes),'Newton term rows',len(detailed),'derivative term rows',len(partials),'W5 result P',W5['P_MN'])
