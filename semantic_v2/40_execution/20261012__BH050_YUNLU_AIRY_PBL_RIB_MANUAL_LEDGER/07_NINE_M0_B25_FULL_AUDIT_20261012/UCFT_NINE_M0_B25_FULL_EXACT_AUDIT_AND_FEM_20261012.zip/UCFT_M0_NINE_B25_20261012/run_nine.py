"""Run 9 elastic M0 curves with analytic integration; only algebraic root solving is numerical."""
import csv,zipfile,io,math,json,time
from pathlib import Path
import numpy as np
from scipy.optimize import root
from analytic_fourier_M0_engine import Model
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).parent; SRC=Path('/mnt/data/UCFT_NINE_END_CREST_AUDIT_DELIVERY(1).zip')
CASES=['BH005','BH010','BH020','BH032','BH050','BH060','BH070','BH085','BH100']
BDS=[250,500,1000,1600,2500,3000,3500,4250,5000]
ALL=[];CMPS=[];SUM=[];SRCROWS=[]
with zipfile.ZipFile(SRC) as z:
 for case,B in zip(CASES,BDS):
  stamp=time.time(); mdl=Model(B)
  fem=list(csv.DictReader(io.StringIO(z.read(f'{case}_FRAMES.csv').decode('utf-8-sig'))))
  FEM=[dict(case=case,frame=int(q['frame']),step=q['step'],phase=q['phase'],W_FEM_mm=float(q['w_added_centerline_n2_mm']),P_FEM_MN=float(q['P_load_MN']),time_s=float(q['time_s']),source=f'{SRC.name}::{case}_FRAMES.csv',disp_definition=q['crest_definition']) for q in fem]
  SRCROWS+=FEM
  wmax=B/25
  # Uniform 1/120 wmax grid plus FEM actual w frames. More small W points to cover thin specimens.
  targeted=np.unique(np.r_[np.linspace(0,wmax,121),np.geomspace(max(wmax*1e-7,1e-5),wmax/200,24),[max(0,q['W_FEM_mm']) for q in FEM if q['W_FEM_mm']<=wmax+1e-8]])
  traj=[]; last=[0.,0.,0.];last2=None;failed=0;worst=0.;jump=0; origin_connected=True
  for W in targeted:
   W=float(W)
   if W==0:z0=mdl.solve(W)
   else:
    # predictor using last two states when available, but reject aggressive extrapolation
    seed=last
    if len(traj)>=2:
     prev=traj[-1]; prior=traj[-2]
     dt=prev['W_mm']-prior['W_mm']
     if dt>0 and all(math.isfinite(prev[q]) and math.isfinite(prior[q]) for q in ['Ap_mm','Am_mm','eps_y0']):
      f=min((W-prev['W_mm'])/dt,2.)
      probe=np.array([prev['Ap_mm'],prev['Am_mm'],prev['eps_y0']])+f*(np.array([prev['Ap_mm'],prev['Am_mm'],prev['eps_y0']])-np.array([prior['Ap_mm'],prior['Am_mm'],prior['eps_y0']]))
      if np.all(np.isfinite(probe)):seed=probe
    trials=[seed,last,[0.,0.,-W/(B*30)], [mdl.A0*W/max(wmax,1),mdl.A0*W/max(wmax,1),-W/(B*30)]]
    candidates=[]
    for test in trials:
     v=mdl.solve(W,test)
     mx=max(abs(q) for q in v['residuals'])
     if math.isfinite(mx) and mx<1e-3:
      d=np.linalg.norm((np.array([v['Ap'],v['Am']])-np.array(last[:2]))/max(mdl.A0,1e-6))
      candidates.append((d,v))
     if candidates and candidates[-1][0]<5:break
    if candidates:z0=min(candidates,key=lambda t:t[0])[1]
    else:
     z0=v;z0['ok']=False;failed+=1
   mx=max(abs(q) for q in z0['residuals']);worst=max(worst,mx)
   if not z0['ok']:origin_connected=False
   phys=(mdl.A0+z0['Ap']>=-1e-9 and mdl.A0+z0['Am']>=-1e-9)
   rec=dict(case=case,B_mm=B,L_mm=2*B,a_h_mm=B,W_mm=W,W_over_B=W/B,A0_mm=mdl.A0,Ap_mm=z0['Ap'],Am_mm=z0['Am'],Aplus_total_mm=mdl.A0+z0['Ap'],Aminus_total_mm=mdl.A0+z0['Am'],eps_y0=z0['e'],eps_x0=z0.get('ex',np.nan),P_theory_MN=z0['P'],R_W_N=z0['residuals'][0],R_plus_N=z0['residuals'][1],R_minus_N=z0['residuals'][2],abs_res_max_N=mx,algebraic_root_accepted=bool(z0['ok']),one_sided_outward_compatible=bool(phys),origin_connected_candidate=bool(origin_connected and z0['ok']),m=4,N_plus=5,N_minus=6)
   traj.append(rec);ALL.append(rec)
   if z0['ok']:last=[z0['Ap'],z0['Am'],z0['e']]
  # match FEM frames to exactly solved W through nearest match, no interpolation FEM.
  for q in FEM:
   close=min(traj,key=lambda rr:abs(rr['W_mm']-q['W_FEM_mm']))
   if abs(close['W_mm']-q['W_FEM_mm'])>2e-8:continue
   cmp=dict(**q, theory_P_MN=close['P_theory_MN'], theory_Ap_mm=close['Ap_mm'],theory_Am_mm=close['Am_mm'],M0_minus_FEM_MN=close['P_theory_MN']-q['P_FEM_MN'],relative_error_Pu_based_percent=100*(close['P_theory_MN']-q['P_FEM_MN'])/max(qq['P_FEM_MN'] for qq in FEM),root_ok=close['algebraic_root_accepted'],outward_compatible=close['one_sided_outward_compatible'])
   CMPS.append(cmp)
  pf=max(FEM,key=lambda q:q['P_FEM_MN']); closest=min(traj,key=lambda q:abs(q['W_mm']-pf['W_FEM_mm']))
  valid=[r for r in traj if r['algebraic_root_accepted'] and r['one_sided_outward_compatible']]
  first_bad=next((r for r in traj if r['algebraic_root_accepted'] and not r['one_sided_outward_compatible']),None)
  full=traj[-1]
  SUM.append(dict(case=case,B_mm=B,W_limit_mm=wmax,FEM_Wmax_mm=max(q['W_FEM_mm'] for q in FEM),FEM_Pu_MN=pf['P_FEM_MN'],FEM_W_at_Pu_mm=pf['W_FEM_mm'],theory_P_at_FEM_peak_W_MN=closest['P_theory_MN'],theory_minus_FEM_peak_MN=closest['P_theory_MN']-pf['P_FEM_MN'],peak_W_error_percent=100*(closest['P_theory_MN']-pf['P_FEM_MN'])/pf['P_FEM_MN'],theory_P_at_B25_MN=full['P_theory_MN'],theory_Ap_B25_mm=full['Ap_mm'],theory_Am_B25_mm=full['Am_mm'],first_outward_invalid_W_mm=first_bad['W_mm'] if first_bad else '',M0_outward_valid_endpoint_W_mm=max(q['W_mm'] for q in valid) if valid else 0,num_theory_pts=len(traj),num_failed_pts=failed,first_nonconverged_W_mm=next((t['W_mm'] for t in traj if not t['algebraic_root_accepted']),''),last_origin_connected_W_mm=max((t['W_mm'] for t in traj if t['origin_connected_candidate']),default=0),max_abs_res_N=worst,elapsed_s=time.time()-stamp))
  # 2 separate figures per case: full W, comparison-domain zoom. Same source data; no FEM extrapolation.
  for zoom in (False,True):
   fig,ax=plt.subplots(figsize=(8,4.6))
   # Preserve NaN gaps to prevent drawing false smooth continuations across missing roots.
   ax.plot([r['W_mm'] for r in traj],[r['P_theory_MN'] if r['algebraic_root_accepted'] else np.nan for r in traj],label='Elastic M0 algebraic roots (gaps retained)',linewidth=1.6)
   eligible=[r for r in traj if r['algebraic_root_accepted'] and r['one_sided_outward_compatible'] and r['origin_connected_candidate']]
   if eligible:ax.plot([r['W_mm'] for r in eligible],[r['P_theory_MN'] for r in eligible],label='Outward + origin-connected candidate',linewidth=2.2)
   ax.plot([q['W_FEM_mm'] for q in FEM],[q['P_FEM_MN'] for q in FEM],marker='o',markersize=2.5,label='GS_DIRECT FE frames',linewidth=1.7)
   ax.set_xlim(0,max(q['W_FEM_mm'] for q in FEM)*1.03 if zoom else wmax)
   ax.set_xlabel('Added global out-of-plane deflection W (mm)')
   ax.set_ylabel('Axial load P (MN)')
   ax.set_title(f'{case} | M0 upper N=5 / lower N=6 / m=4 | '+('FEM domain' if zoom else 'W to B/25'))
   ax.grid(alpha=.3);ax.legend(loc='best',fontsize=8)
   fig.tight_layout();fig.savefig(ROOT/f'{case}_M0_vs_GS_DIRECT_{"FEMrange" if zoom else "B25"}.png',dpi=160);plt.close(fig)
  print(case,'pts',len(traj),'fail',failed,'worst',worst,'P_B25',full['P_theory_MN'],'FEM_Pu',pf['P_FEM_MN'],'firstinvalid',first_bad and first_bad['W_mm'],'elapsed',round(time.time()-stamp,2),flush=True)

def save(path,rows):
 with (ROOT/path).open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0].keys()));wr.writeheader();wr.writerows(rows)
save('01_NINE_M0_all_formula_roots_to_B25.csv',ALL)
save('02_NINE_GS_DIRECT_source_frames.csv',SRCROWS)
save('03_NINE_M0_at_all_FEM_frames.csv',CMPS)
save('04_NINE_summary_peak_and_B25.csv',SUM)
(ROOT/'05_NINE_run_metadata.json').write_text(json.dumps({'method':'analytic Fourier convolution and definite primitives, no spatial Gaussian quadrature','m':4,'N_upper':5,'N_lower':6,'reference':'BH050 M0 W=5mm ledger (20261012)','fem_zip':str(SRC),'fem_def':'w_added_centerline_n2_mm; load P_load_MN','source_limit':'FEM data not extrapolated beyond recorded max W','inputs':{c:dict(B=B,L=2*B,w0=B/400,A0=.225*B/1600) for c,B in zip(CASES,BDS)}},ensure_ascii=False,indent=2),encoding='utf-8')
