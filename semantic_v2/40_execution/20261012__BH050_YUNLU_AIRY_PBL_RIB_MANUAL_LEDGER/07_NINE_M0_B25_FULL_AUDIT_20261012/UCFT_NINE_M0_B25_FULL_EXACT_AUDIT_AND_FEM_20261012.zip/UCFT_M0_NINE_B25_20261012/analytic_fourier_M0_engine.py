"""Finite-harmonic exact integration, NOT spatial-grid/quadrature integration.
All x/y products are Fourier convolutions; each harmonic is integrated by its analytic primitive.
Pure elastic M0, upper N=5, lower N=6, axial m=4 (as previously frozen BH050 demo).
"""
import math, cmath, csv, json
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.optimize import root

class F:
 def __init__(self,d=None): self.d={k:complex(v) for k,v in (d or {}).items() if abs(v)>1e-26}
 def __add__(self,o):
  if not isinstance(o,F): o=F({(0,0):o})
  d=self.d.copy()
  for k,v in o.d.items():d[k]=d.get(k,0)+v
  return F(d)
 __radd__=__add__
 def __neg__(self):return self*(-1)
 def __sub__(self,o):return self+(-o if isinstance(o,F) else -o)
 def __rsub__(self,o):return o+(-self)
 def __mul__(self,o):
  if not isinstance(o,F):return F({k:v*o for k,v in self.d.items()})
  d={}
  for (i,j),v in self.d.items():
   for (k,l),w in o.d.items():d[(i+k,j+l)]=d.get((i+k,j+l),0)+v*w
  return F(d)
 __rmul__=__mul__
 def der(self,nx,ny,alpha,beta):return F({(i,j):v*(1j*i*alpha)**nx*(1j*j*beta)**ny for (i,j),v in self.d.items()})
 def biharm_inv(self,alpha,beta):
  d={}
  for (i,j),v in self.d.items():
   k2=(i*alpha)**2+(j*beta)**2
   if k2<1e-35:
    if abs(v)>1e-16:raise RuntimeError(f'Nonzero period mean compatibility source {v}')
    continue
   d[(i,j)]=v/k2**2
  return F(d)
 @staticmethod
 def trig(kind,n,ax):
  if n==0:
   if kind=='sin':return F()
   return F({(0,0):1})
  k=(n,0) if ax==0 else (0,n);km=(-n,0) if ax==0 else (0,-n)
  if kind=='cos':return F({k:0.5,km:0.5})
  return F({k:-0.5j,km:0.5j})
 @staticmethod
 def const(c=1):return F({(0,0):c})
 @staticmethod
 @lru_cache(maxsize=None)
 def one_integral(n):
  if n==0:return 1.0
  return 2j/(math.pi*n) if n%2 else 0j
 def avg(self,ledger=None,name=''):
  ss=0j
  for (i,j),v in sorted(self.d.items()):
   xi=F.one_integral(i); yj=F.one_integral(j); term=v*xi*yj
   if ledger is not None:ledger.append([name,i,j,f'{v.real:.16g}',f'{v.imag:.16g}',f'{xi.real:.16g}',f'{xi.imag:.16g}',f'{yj.real:.16g}',f'{yj.imag:.16g}',f'{term.real:.16g}',f'{term.imag:.16g}'])
   ss+=term
  if abs(ss.imag)>2e-7*max(abs(ss.real),1):raise RuntimeError(f'Non-real integral {name}: {ss}')
  return float(ss.real)

class Model:
 def __init__(self,B,tc=42,ts=4,Es=206000,nus=.3,Ec=43400,nuc=.2,m=4,A0=None,save_terms=False):
  self.B=B;self.a=B;self.tc=tc;self.ts=ts;self.Es=Es;self.Ec=Ec;self.nus=nus;self.nuc=nuc;self.m=m
  self.alpha=math.pi/B;self.beta=math.pi/B;self.zf=(tc+ts)/2;self.w0=B/400;self.A0=.225*B/1600 if A0 is None else A0
  self.Ks=Es/(1-nus**2);self.Kc=Ec/(1-nuc**2)
  self.Ds=Es*ts**3/(12*(1-nus**2));self.Dc=Ec*tc**3/(12*(1-nuc**2))
  alpha,beta=self.alpha,self.beta
  sx=lambda n:F.trig('sin',n,0);cx=lambda n:F.trig('cos',n,0)
  sy=lambda n:F.trig('sin',n,1);cy=lambda n:F.trig('cos',n,1)
  self.phi=sx(1)*sy(1)
  self.psi={5:(F.const()-cx(10))*(F.const()-cy(2*m)),6:(F.const()-cx(12))*(F.const()-cy(2*m))}
  self.ledger=[] if save_terms else None
  self.g=self.make_terms(self.phi,'G')
  self.s={N:self.make_terms(self.psi[N],f'L{N}') for N in (5,6)}
  self.x={N:self.make_terms_cross(self.phi,self.psi[N],f'X{N}') for N in (5,6)}
  self.vp=self.gradient_virtual(self.phi,self.phi)
  self.mphi={N:self.gradient_virtual(self.phi,self.psi[N]) for N in (5,6)}
  self.vpsi={N:self.gradient_virtual(self.psi[N],self.psi[N]) for N in (5,6)}
  self.vz=(-self.phi.der(2,0,alpha,beta),-self.phi.der(0,2,alpha,beta),-2*self.phi.der(1,1,alpha,beta))
  self.vv={}
  for N in (5,6):
   vs=[F.const(),self.g[1][0],self.s[N][1][0],self.x[N][1][0]]
   # dot tables: for (stress g, l, cross, uniform), virtual (phi, mix, psi, curvature)
   vb=[self.vp,self.mphi[N],self.vpsi[N],self.vz]
   self.vv[N]={}
   for tag,ff in [('Ux',(F.const(),F(),F())),('Uy',(F(),F.const(),F())),('G',self.g[1]),('L',self.s[N][1]),('X',self.x[N][1])]:
    for k,vs in zip(['pp','mp','ss','zz'],vb):
     v=ff[0]*vs[0]+ff[1]*vs[1]+ff[2]*vs[2]
     self.vv[N][(tag,k)]=v.avg(self.ledger,f'overlap_N{N}_{tag}_{k}')
  self.vv_core={}
  for tag,ff in [('Ux',(F.const(),F(),F())),('Uy',(F(),F.const(),F())),('G',self.g[1])]:
   v=ff[0]*self.vp[0]+ff[1]*self.vp[1]+ff[2]*self.vp[2]
   self.vv_core[tag]=v.avg(self.ledger,f'overlap_core_{tag}')
  self.chi_coef={}
  for N in (5,6):
   psi=self.psi[N]
   self.chi_coef[N]={}
   for d in [(1,0),(0,1)]:
    p=self.phi.der(*d,alpha,beta);q=psi.der(*d,alpha,beta)
    self.chi_coef[N][d]=[.5*(p*p).avg(self.ledger,f'chi_phi2_{N}_{d}'),(p*q).avg(self.ledger,f'chi_mix_{N}_{d}'),.5*(q*q).avg(self.ledger,f'chi_loc2_{N}_{d}')]
  self.curv_avg=(self.phi.der(2,0,alpha,beta).avg(self.ledger,'mean_phi_xx'),self.phi.der(0,2,alpha,beta).avg(self.ledger,'mean_phi_yy'))
  self.i00=self.bending(self.phi,self.phi)
  self.i0={N:self.bending(self.phi,self.psi[N]) for N in (5,6)}
  self.ii={N:self.bending(self.psi[N],self.psi[N]) for N in (5,6)}
 def gradient_virtual(self,f,g):
  a,b=self.alpha,self.beta
  fx=f.der(1,0,a,b);fy=f.der(0,1,a,b);gx=g.der(1,0,a,b);gy=g.der(0,1,a,b)
  return(fx*gx,fy*gy,fx*gy+fy*gx)
 def make_terms(self,shape,name):
  a,b=self.alpha,self.beta
  xx=shape.der(2,0,a,b);yy=shape.der(0,2,a,b);xy=shape.der(1,1,a,b)
  source=xy*xy-xx*yy
  return self.stress_coeff(source,name)
 def make_terms_cross(self,f,g,name):
  a,b=self.alpha,self.beta
  source=2*f.der(1,1,a,b)*g.der(1,1,a,b)-f.der(2,0,a,b)*g.der(0,2,a,b)-g.der(2,0,a,b)*f.der(0,2,a,b)
  return self.stress_coeff(source,name)
 def stress_coeff(self,source,name):
  a,b=self.alpha,self.beta
  airy=source.biharm_inv(a,b)
  orig=(airy.der(0,2,a,b),airy.der(2,0,a,b),-airy.der(1,1,a,b))
  # centralize x and y stresses, and also tau per zero-shear gauge
  coeff=tuple(xx-xx.avg(self.ledger,name+'_mean_'+str(i)) for i,xx in enumerate(orig))
  return airy,coeff
 def bending(self,f,g):
  a,b=self.alpha,self.beta;nu=self.nus
  fx=f.der(2,0,a,b);fy=f.der(0,2,a,b);fxy=f.der(1,1,a,b)
  gx=g.der(2,0,a,b);gy=g.der(0,2,a,b);gxy=g.der(1,1,a,b)
  density=fx*gx+fy*gy+nu*(fx*gy+fy*gx)+2*(1-nu)*fxy*gxy
  return density.avg(self.ledger,f'BEND_{len(f.d)}_{len(g.d)}')*self.B*self.a
 def compute(self,W,Ap,Am,e,details=False):
  Qg=W*(W+2*self.w0)
  exy=[];sigma=[];chi=[]
  for N,s,A in [(5,1,Ap),(6,-1,Am)]:
   ql=A*(A+2*self.A0);qx=W*self.A0+(self.w0+W)*A
   cx=self.chi_coef[N][(1,0)];cy=self.chi_coef[N][(0,1)]
   chi.append([ -s*self.zf*W*self.curv_avg[0]+Qg*cx[0]+s*qx*cx[1]+ql*cx[2],-s*self.zf*W*self.curv_avg[1]+Qg*cy[0]+s*qx*cy[1]+ql*cy[2]])
  core_chi=[Qg*self.chi_coef[5][(1,0)][0],Qg*self.chi_coef[5][(0,1)][0]]
  D=self.tc*self.Kc+2*self.ts*self.Ks
  H=self.tc*self.Kc*self.nuc+2*self.ts*self.Ks*self.nus
  other=self.tc*self.Kc*(core_chi[0]+self.nuc*core_chi[1])
  for c in chi:other+=self.ts*self.Ks*(c[0]+self.nus*c[1])
  ex=-(H*e+other)/D
  scx=self.Kc*(ex+core_chi[0]+self.nuc*(e+core_chi[1]))
  scy=self.Kc*(self.nuc*(ex+core_chi[0])+e+core_chi[1])
  allsig=[(scx,scy)]
  for c in chi:
   sxx=self.Ks*(ex+c[0]+self.nus*(e+c[1]));syy=self.Ks*(self.nus*(ex+c[0])+e+c[1]); allsig.append((sxx,syy))
  RW_b=(self.Dc+2*self.Ds)*W*self.i00+self.Ds*(Ap*self.i0[5]-Am*self.i0[6])
  RP_b=self.Ds*(W*self.i0[5]+Ap*self.ii[5]);RM_b=self.Ds*(-W*self.i0[6]+Am*self.ii[6])
  # Each pre-integrated zero-mean Airy stress field multiplied by its analytic geometric polynomial amplitude.
  def ds(N,s,A,barX,barY,mode):
   v=self.vv[N];ql=A*(A+2*self.A0);qx=W*self.A0+(self.w0+W)*A
   def dt(k):
    return(barX*v[('Ux',k)]+barY*v[('Uy',k)]+self.Es*(Qg*v[('G',k)]+ql*v[('L',k)]+s*qx*v[('X',k)]))
   if mode=='W':return self.ts*self.B*self.a*((self.w0+W)*dt('pp')+s*(self.A0+A)*dt('mp')+s*self.zf*dt('zz'))
   else:return self.ts*self.B*self.a*(s*(self.w0+W)*dt('mp')+(self.A0+A)*dt('ss'))
  coremem=self.tc*self.B*self.a*(scx*self.vv_core['Ux']+scy*self.vv_core['Uy']+self.Ec*Qg*self.vv_core['G'])*(self.w0+W)
  RW=RW_b+coremem+ds(5,1,Ap,*allsig[1],'W')+ds(6,-1,Am,*allsig[2],'W')
  RP=RP_b+ds(5,1,Ap,*allsig[1],'A');RM=RM_b+ds(6,-1,Am,*allsig[2],'A')
  P=-self.B*(self.tc*scy+self.ts*allsig[1][1]+self.ts*allsig[2][1])/1e6
  if details:return dict(RW=RW,RP=RP,RM=RM,P=P,ex=ex,e=e,avg=[(scx,scy)]+allsig[1:],chi=[core_chi]+chi,bending=[RW_b,RP_b,RM_b],membrane=[coremem,ds(5,1,Ap,*allsig[1],'W'),ds(6,-1,Am,*allsig[2],'W'),ds(5,1,Ap,*allsig[1],'A'),ds(6,-1,Am,*allsig[2],'A')])
  return np.array([RW,RP,RM],dtype=float),P
 def solve(self,W,seed=None,tol=1e-9):
  if abs(W)<1e-14:return dict(W=W,Ap=0.,Am=0.,e=0.,P=0.,residuals=[0.,0.,0.],ok=True)
  if seed is None:seed=[0.,0.,-1e-4*W/(self.B/2500)]
  def fun(x):return self.compute(W,*x)[0]/1e5
  res=root(fun,seed,method='hybr',options={'xtol':1e-11,'maxfev':600})
  out=self.compute(W,*res.x,details=True)
  maxr=max(abs(out[k]) for k in ('RW','RP','RM'))
  return dict(W=W,Ap=float(res.x[0]),Am=float(res.x[1]),e=float(res.x[2]),P=float(out['P']),residuals=[float(out[x]) for x in ('RW','RP','RM')],ok=maxr<=tol*1e5,evals=int(res.nfev),status=res.message,ex=float(out['ex']),avg_y=[float(o[1]) for o in out['avg']])

if __name__=='__main__':
 mdl=Model(2500,save_terms=False)
 for W in [0.2,1,5]:print('POINT',mdl.solve(W,[0,0,-0.0002]))
 print('I',mdl.i00,mdl.i0,mdl.ii,'Cx',mdl.chi_coef[5][(1,0)][1],mdl.chi_coef[6][(1,0)][1])
