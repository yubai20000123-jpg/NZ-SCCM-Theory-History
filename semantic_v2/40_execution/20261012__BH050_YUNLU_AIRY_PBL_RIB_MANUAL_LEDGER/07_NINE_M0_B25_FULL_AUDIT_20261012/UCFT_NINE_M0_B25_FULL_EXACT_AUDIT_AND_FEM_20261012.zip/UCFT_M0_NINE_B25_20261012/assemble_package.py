import csv,hashlib,zipfile,shutil,os,datetime
from pathlib import Path
R=Path(__file__).parent
rows=list(csv.DictReader((R/'04_NINE_summary_peak_and_B25.csv').open(encoding='utf-8-sig')))
fmt=lambda x:f'{float(x):.4f}'
header=['试件','B(mm)','截断 W=B/25 (mm)','FEM 最大记录 W(mm)','FEM Pu(MN)','FEM 峰值 W(mm)','M0 在同 W 的 P(MN)','峰值 W 处误差(%)','M0 截断 P(MN)','M0单侧方向首先失效 W(mm)','求根失败点数']
lines=['| '+' | '.join(header)+' |','|'+'|'.join(['---']*len(header))+'|']
for r in rows:
 data=[r['case'],r['B_mm'],fmt(r['W_limit_mm']),fmt(r['FEM_Wmax_mm']),fmt(r['FEM_Pu_MN']),fmt(r['FEM_W_at_Pu_mm']),fmt(r['theory_P_at_FEM_peak_W_MN']),f"{float(r['peak_W_error_percent']):+.2f}",fmt(r['theory_P_at_B25_MN']),r['first_outward_invalid_W_mm'] and fmt(r['first_outward_invalid_W_mm']) or '未发现',r['num_failed_pts']]
 lines.append('| '+' | '.join(data)+' |')
summary='\n'.join(lines)
# zero data fig source and proof
shutil.copy('/mnt/data/01_nine_specimens_rib_coordinates.csv',R/'00_upstream_real_PBL_ribs.csv')
D=R/'BH050_W5_00_complete_human_reproduction_readme.md'
text=f'''# 九试件 M0 Airy—Galerkin 截止 W=B/25：理论与 GS_DIRECT FEM 比对暨可追溯计算报告

报告时间：2026-10-12；模型身份：M0 三层各向同性线弹性、上下钢面分别 N+=5/N-=6 横向**等分等效子板**，轴向 m=4 固定为上一次 BH050 首组示范，不做选择性优化。

## 1. 计算输入及统一范围

试件为 BH005, BH010, BH020, BH032, BH050, BH060, BH070, BH085, BH100。板宽 B 分别为 250,500,1000,1600,2500,3000,3500,4250,5000 mm，L=2B；整体计算半波 a_h=B，取 w0=B/400；本次局部初始 A0±=0.3515625 B/2500=0.000140625B mm（沿用历史参数本）；tc=42 mm、ts=4 mm、Es=206000 MPa、νs=0.30、Ec=43400 MPa、νc=0.20。真实 PBL 是上4根、下5根纵肋、横肋0根；真实分布未强制作为本组等分形函数节点，不含肋自身轴向力。源坐标完整拷贝至文件 00_upstream_real_PBL_ribs.csv。

理论线弹性、Airy 有限谐波、三层平均膜应变协调。空间积分是有限谐波逐项原函数的精确积分，**没有使用高斯积分点，也没有把FEM数据输入理论求根**。三个代数残量 R_W、R_+、R_- 联立求解公共 ε_y0、A_+、A_-，由平均纵向截面内力 P_N=−B[tc σbar_yc+ts σbar_y++ts σbar_y−]/10^6 MN 恢复荷载。该 P_N 尚未计入真实实体肋的单独轴力。

## 2. 九试件结果总表

{summary}

**重要：**第 9 列的 P(W=B/25) 是数学代数根的结果，**不是承载力极限**。尤其在钢壳向外单侧变形约束失效后，只允许作为方程值，不允许作为当前简化模型的物理预测。BH005 和 BH010 有固定 W 的代数求根失效区间，不能在图上自动跨越成连续分支。

## 3. FEM 证据和曲线定义

FEM 来源：随对话环境提供的原有资料包 UCFT_NINE_END_CREST_AUDIT_DELIVERY(1).zip 内每试件 BHxxx_FRAMES.csv。字段 P_load_MN 为加载端反力，w_added_centerline_n2_mm 为相对帧0并扣除端点弦线的整体中线新增面外位移（第二半波读数）；它不是加载端缩短量。每试件 23–25 帧，与最新 GS_DIRECT 接触恢复基线对应。FEM 没有外推到 B/25；在超出 FEM 已实际覆盖的 W 区域，仅画理论分支。

理论与 FEM 按相同数值 W 进行采样点比较，不以 FEM 最大荷载反标定理论。误差 = [P_M0(W_FEM峰)−P_FEM峰]/P_FEM峰。FEM 的峰值本身可能发生在多个相近 W 帧，保留各帧原序与阶段标签。

## 4. 观察到的物理趋势

- BH005/BH010/BH020 的 M0 在 FEM 峰值对应 W 上高估约 205.10%、52.17%、27.03%，说明小 B、高刚度组有强烈几何/理想边界偏差。
- BH032 在峰值 W 处低估约 10.27%；BH050、BH060、BH070 分别低估约 35.28%、40.64%、31.30%；BH085、BH100 分别低估约 15.29%、9.11%。
- 数学线弹性 M0 大挠度端继续上升，FEM 的大挠度阶段会下降；不能用这个线弹性模型解释真实钢材屈服、UHPC 损伤塑性、局部脱空与 PBL 传力引起的峰后软化。
- 从 BH032 起，到某些 W，A0+A+<0，所采用向外正鼓曲的单侧约束被破坏；这类采样必须标记 out-of-domain，不是“新的有效负幅值钢壳分支”。
- BH005、BH010 还出现数学上求根中断或多根共存。绘图严格保留空缺，后续如要追踪折返必须另作完整的弧长分支判定，不能用直接W扫描跨根。

## 5. 全部文件的复算顺序

1. 读取 `analytic_fourier_M0_engine.py`：所有正余弦化为双变量有限傅里叶频率对 (n_x,n_y)；卷积完成积化和差；每个傅里叶频率使用解析定积分。Airy应力直接来自兼容源的双调和逆算子。
2. 阅读 `BH050_W5_00_complete_human_reproduction_readme.md`：材料参数到每一个符号、几何应变/应力、膜弯三个虚功、公共横向应变与轴向应变消元、牛顿算式。
3. 按 `BH050_W5_02_every_Airy_and_stress_harmonic.csv` 恢复每个 Airy 谐波、各应力分量；按 `BH050_W5_01_every_Fourier_integral_term.csv` 的 3616 行检查每项解析积分原函数的乘积和累加。
4. 按 `BH050_W5_03_all_polynomial_coefficients.csv` 得到全部 13＋10＋10 个平衡单项式，以及轴力多项式；按 `BH050_W5_04_all_Newton_steps.csv` 的 9 轮复算，`BH050_W5_05_every_Newton_monomial_product.csv` 每项核查和、`BH050_W5_06_every_Jacobian_polynomial_term.csv` 每项核查导数。
5. 核对 `BH050_W5_07_final_state_all_layer_values.json` 中的 UHPC/上钢面/下钢面应力、轴力、弯曲残量和膜虚功。
6. 对九试件依次读 `01_NINE_M0_all_formula_roots_to_B25.csv` 的全部状态，`02_NINE_GS_DIRECT_source_frames.csv` 的 FEM 帧，`03_NINE_M0_at_all_FEM_frames.csv` 的同 W 对比，`04_NINE_summary_peak_and_B25.csv` 的结果摘要，核查两套绘图是否均没有将 FEM 曲线延长到 B/25。

## 6. 未闭合及未做的事情

(1) 不满足实际实体 PBL 的精确肋线位移与传力条件；(2) 未满足所有外边界的逐点面内牵引条件；(3) UHPC 和钢材按线弹性假定，没有 Mises、塑性和损伤；(4) m=4 未在九件中进行稳定模态优选；(5) 未判定每一个 W 值全部代数根的稳定性；(6) 含向内总鼓曲的数学分支违反单侧外鼓假定；(7) BH005/BH010 在部分 W 上无经原分支追踪验证的合格根；(8) 所给 W 与 FEM 第二半波中线新增挠度只采用幅值层面的对应，实际曲面场/边界不相同，不能将误差解释为单纯材料误差。

结论：本轮完成九件 W=B/25 范围的数学方程采样、九条 FEM 原始帧对比和 BH050 W=5 mm 人工复算；**未完成九件严格物理约束下的连续稳定平衡分支及真实极限强度预测**。
'''.replace('\u0004','`')
(R/'README_九试件结果与复算状态.md').write_text(text,encoding='utf-8')
# Manifest complete files excluding temp and generated JSON if? yes
files=[p for p in R.iterdir() if p.is_file() and not p.name.startswith('_') and p.name not in ['assemble_package.py']]
lines=['path,bytes,sha256']
for p in sorted(files):
 lines.append(f'{p.name},{p.stat().st_size},{hashlib.sha256(p.read_bytes()).hexdigest()}')
(R/'MANIFEST_SHA256.csv').write_text('\n'.join(lines)+'\n',encoding='utf-8')
archive=Path('/mnt/data/UCFT_NINE_M0_B25_FULL_EXACT_AUDIT_AND_FEM_20261012.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in R.iterdir():
  if p.is_file() and not p.name.startswith('_'):z.write(p,arcname=f'UCFT_M0_NINE_B25_20261012/{p.name}')
print('archive',archive,'bytes',archive.stat().st_size,'files',len(z.namelist()))
