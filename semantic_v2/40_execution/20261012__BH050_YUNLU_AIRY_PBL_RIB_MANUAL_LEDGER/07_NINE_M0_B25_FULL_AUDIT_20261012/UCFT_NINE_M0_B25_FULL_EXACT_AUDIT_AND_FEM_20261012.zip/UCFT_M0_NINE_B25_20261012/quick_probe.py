from analytic_fourier_M0_engine import Model
for B in [250,500,1000,1600,2500,3000,3500,4250,5000]:
 m=Model(B)
 seed=[0,0,0]
 print('B=',B,'Wmax=',B/25,flush=True)
 for frac in [.001,.002,.005,.01,.02,.03,.04]:
  W=B*frac
  z=m.solve(W,seed);seed=[z['Ap'],z['Am'],z['e']]
  print(f" {W:.3f} A+={z['Ap']:.5g} A-={z['Am']:.5g} e={z['e']:.4e} P={z['P']:.4g} ok={z['ok']} res={max(abs(t) for t in z['residuals']):.3g}",flush=True)
